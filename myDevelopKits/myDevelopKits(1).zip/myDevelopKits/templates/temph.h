#ifndef __xxxx_H__
#define __xxxx_H__

#ifdef __cplusplus
extern "C" {
#endif
#include "basic_f.h"
#include "glb_cfg.h"

//macro


//typedef


//var


//macro func


//mix


//func



#ifdef __cplusplus
}
#endif
#endif


